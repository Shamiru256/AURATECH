const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

const dir = process.env.DATA_DIR || path.join(__dirname, 'data');
fs.mkdirSync(dir, { recursive: true });

const db = new Database(path.join(dir, 'aura.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS products (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  name        TEXT NOT NULL,
  description TEXT NOT NULL,
  category    TEXT NOT NULL,
  price_ugx   INTEGER NOT NULL,
  active      INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS orders (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  reference     TEXT NOT NULL UNIQUE,
  customer_name TEXT NOT NULL,
  email         TEXT NOT NULL,
  phone         TEXT,
  items         TEXT NOT NULL,
  amount        REAL NOT NULL,
  currency      TEXT NOT NULL,
  provider      TEXT NOT NULL,
  provider_ref  TEXT,
  status        TEXT NOT NULL DEFAULT 'pending',
  created_at    TEXT NOT NULL DEFAULT (datetime('now')),
  paid_at       TEXT
);

CREATE TABLE IF NOT EXISTS messages (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  name       TEXT NOT NULL,
  email      TEXT NOT NULL,
  phone      TEXT,
  subject    TEXT,
  message    TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS settings (
  key   TEXT PRIMARY KEY,
  value TEXT
);
`);

// Seed example catalogue (prices are placeholders: edit them in the database or via the admin API).
if (db.prepare('SELECT COUNT(*) AS n FROM products').get().n === 0) {
  const ins = db.prepare(
    'INSERT INTO products (name, description, category, price_ugx) VALUES (?, ?, ?, ?)'
  );
  const seed = [
    ['Business Website Package', 'Responsive company website with contact forms, SEO basics and 1 year of hosting support.', 'Web & Apps', 1500000],
    ['Custom Web / Mobile App', 'Discovery, UI design, development and deployment for your business app (starting price).', 'Web & Apps', 5000000],
    ['Network & Wi-Fi Installation', 'Structured cabling, router and access-point setup for offices and schools (up to 20 users).', 'Networking', 1200000],
    ['CCTV Installation (4 cameras)', 'Supply and install a 4-camera HD CCTV system with remote viewing on your phone.', 'Security', 1800000],
    ['Monthly IT Support Plan', 'Remote and on-site support, backups, antivirus and system updates for small businesses.', 'IT Support', 350000],
    ['Cloud Hosting & Email Setup', 'Domain, hosting and professional business email set up and secured.', 'Cloud', 400000],
    ['Computer & Software Training', 'Hands-on training for staff or students: Office, web basics, digital skills (per group).', 'Training', 600000],
    ['Refurbished Business Laptop', 'Tested business-class laptop, 8GB RAM, SSD, 6-month warranty.', 'Hardware', 1450000]
  ];
  const tx = db.transaction(() => seed.forEach(r => ins.run(...r)));
  tx();
}

module.exports = db;
