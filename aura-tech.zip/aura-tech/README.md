# Aura Tech Solutions Uganda: website, API and payments

Stack: HTML/CSS/JavaScript front end, Node.js + Express backend, SQLite database (better-sqlite3).

## Run locally

```bash
npm install
cp .env.example .env     # then edit .env
npm start                # http://localhost:3000
```

The database file is created automatically in `./data/aura.db` and seeded with example services (edit prices there or via the admin API).

## Pages

| URL | Purpose |
| --- | --- |
| `/` | Home, services/shop, cart and checkout, contact form |
| `/terms.html` | Terms & Conditions (template, get it reviewed by an advocate) |
| `/privacy.html` | Privacy Policy (based on Uganda's Data Protection and Privacy Act, 2019) |
| `/status.html?ref=…` | Payment result page (verifies with the gateway) |

## Payment gateways

Each gateway turns on automatically when its keys are present in `.env`.

| Gateway | Use | Keys needed |
| --- | --- | --- |
| Flutterwave | MTN/Airtel Mobile Money (UGX) and cards, international | `FLW_SECRET_KEY`, `FLW_SECRET_HASH` |
| Pesapal v3 | Uganda: Mobile Money, cards, bank | `PESAPAL_CONSUMER_KEY`, `PESAPAL_CONSUMER_SECRET`, `PESAPAL_ENV` |
| Stripe | International cards (USD) | `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET` |

Webhook URLs to register in each dashboard (use your public https `BASE_URL`):

- Flutterwave: `POST {BASE_URL}/webhooks/flutterwave` (set the same secret hash as `FLW_SECRET_HASH`)
- Pesapal: IPN is registered automatically (`GET {BASE_URL}/webhooks/pesapal`)
- Stripe: `POST {BASE_URL}/webhooks/stripe`, event `checkout.session.completed`

Security notes:
- Prices are always computed on the server from the database; the browser only sends item IDs and quantities.
- An order is marked **paid** only after the server re-verifies it with the gateway API (amount and currency checked too), never from a redirect or webhook payload alone.
- Test in sandbox/test mode first. Gateways need a public https URL for callbacks and webhooks (use a tunnel such as ngrok when testing locally).

## Admin API

Send header `x-admin-token: <ADMIN_TOKEN>` (at least 16 characters):

- `GET /api/admin/orders`, `GET /api/admin/messages`
- `POST /api/admin/products` with `{name, description, category, price_ugx}`
- `PUT /api/admin/products/:id` with any fields, `active: 0` hides an item

## Before going live

1. Fill in the bracketed company details in `terms.html` and `privacy.html`, and have an advocate review them.
2. Set a strong `ADMIN_TOKEN`, real `BASE_URL`, `COMPANY_EMAIL`, `COMPANY_PHONE`.
3. Serve behind HTTPS (e.g. Nginx/Caddy, or a host like Render, Railway or a VPS) and keep `data/` on persistent storage with backups.
4. Register with Uganda's Personal Data Protection Office if required for your business.
5. Replace seed prices and services with your real catalogue.
