// Payment gateway adapters. Uses Node 18+ built-in fetch, so no SDKs are needed.
// Each adapter has:  create(order, customer) -> { redirectUrl, providerRef }
//                    verify(order)           -> { paid: boolean, amount?, currency? }
const crypto = require('crypto');
const db = require('./db');

const BASE_URL = () => (process.env.BASE_URL || 'http://localhost:3000').replace(/\/$/, '');

async function json(res) {
  const text = await res.text();
  try { return JSON.parse(text); } catch { throw new Error(`Gateway returned non-JSON (${res.status}): ${text.slice(0, 200)}`); }
}

/* ------------------------------------------------------------------ */
/* Flutterwave: MTN/Airtel Mobile Money Uganda, cards, international    */
/* ------------------------------------------------------------------ */
const flutterwave = {
  enabled: () => !!process.env.FLW_SECRET_KEY,
  async create(order, customer) {
    const res = await fetch('https://api.flutterwave.com/v3/payments', {
      method: 'POST',
      headers: { Authorization: `Bearer ${process.env.FLW_SECRET_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        tx_ref: order.reference,
        amount: order.amount,
        currency: order.currency,
        redirect_url: `${BASE_URL()}/payment/callback?ref=${order.reference}`,
        payment_options: order.currency === 'UGX' ? 'mobilemoneyuganda,card' : 'card',
        customer: { email: customer.email, name: customer.name, phonenumber: customer.phone || undefined },
        customizations: { title: 'Aura Tech Solutions Uganda', description: `Order ${order.reference}` }
      })
    });
    const data = await json(res);
    if (data.status !== 'success') throw new Error(data.message || 'Flutterwave error');
    return { redirectUrl: data.data.link, providerRef: order.reference };
  },
  async verify(order) {
    const res = await fetch(
      `https://api.flutterwave.com/v3/transactions/verify_by_reference?tx_ref=${encodeURIComponent(order.reference)}`,
      { headers: { Authorization: `Bearer ${process.env.FLW_SECRET_KEY}` } }
    );
    const data = await json(res);
    const d = data.data;
    return { paid: data.status === 'success' && d && d.status === 'successful', amount: d && d.amount, currency: d && d.currency };
  }
};

/* ------------------------------------------------------------------ */
/* Pesapal v3: Uganda (Mobile Money, cards, banks)                       */
/* ------------------------------------------------------------------ */
const pesapalBase = () =>
  process.env.PESAPAL_ENV === 'live' ? 'https://pay.pesapal.com/v3' : 'https://cybqa.pesapal.com/pesapalv3';

let pesapalToken = { value: null, expires: 0 };
async function pesapalAuth() {
  if (pesapalToken.value && Date.now() < pesapalToken.expires) return pesapalToken.value;
  const res = await fetch(`${pesapalBase()}/api/Auth/RequestToken`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
    body: JSON.stringify({ consumer_key: process.env.PESAPAL_CONSUMER_KEY, consumer_secret: process.env.PESAPAL_CONSUMER_SECRET })
  });
  const data = await json(res);
  if (!data.token) throw new Error('Pesapal auth failed');
  pesapalToken = { value: data.token, expires: Date.now() + 4 * 60 * 1000 };
  return data.token;
}

async function pesapalIpnId(token) {
  const url = `${BASE_URL()}/webhooks/pesapal`;
  const key = `pesapal_ipn_${process.env.PESAPAL_ENV || 'sandbox'}_${url}`;
  const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(key);
  if (row) return row.value;
  const res = await fetch(`${pesapalBase()}/api/URLRegistration/RegisterIPN`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Accept: 'application/json', Authorization: `Bearer ${token}` },
    body: JSON.stringify({ url, ipn_notification_type: 'GET' })
  });
  const data = await json(res);
  if (!data.ipn_id) throw new Error('Pesapal IPN registration failed');
  db.prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)').run(key, data.ipn_id);
  return data.ipn_id;
}

const pesapal = {
  enabled: () => !!(process.env.PESAPAL_CONSUMER_KEY && process.env.PESAPAL_CONSUMER_SECRET),
  async create(order, customer) {
    const token = await pesapalAuth();
    const ipn = await pesapalIpnId(token);
    const [first, ...rest] = customer.name.split(' ');
    const res = await fetch(`${pesapalBase()}/api/Transactions/SubmitOrderRequest`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({
        id: order.reference,
        currency: order.currency,
        amount: order.amount,
        description: `Aura Tech order ${order.reference}`.slice(0, 100),
        callback_url: `${BASE_URL()}/payment/callback?ref=${order.reference}`,
        notification_id: ipn,
        billing_address: { email_address: customer.email, phone_number: customer.phone || '', first_name: first, last_name: rest.join(' ') || first, country_code: 'UG' }
      })
    });
    const data = await json(res);
    if (!data.redirect_url) throw new Error((data.error && data.error.message) || 'Pesapal order failed');
    return { redirectUrl: data.redirect_url, providerRef: data.order_tracking_id };
  },
  async verify(order) {
    if (!order.provider_ref) return { paid: false };
    const token = await pesapalAuth();
    const res = await fetch(
      `${pesapalBase()}/api/Transactions/GetTransactionStatusByOrderTrackingId?orderTrackingId=${encodeURIComponent(order.provider_ref)}`,
      { headers: { Accept: 'application/json', Authorization: `Bearer ${token}` } }
    );
    const d = await json(res);
    return { paid: d.payment_status_description === 'Completed', amount: d.amount, currency: d.currency };
  }
};

/* ------------------------------------------------------------------ */
/* Stripe Checkout: international cards (USD)                            */
/* ------------------------------------------------------------------ */
const stripe = {
  enabled: () => !!process.env.STRIPE_SECRET_KEY,
  async create(order, customer) {
    const body = new URLSearchParams({
      mode: 'payment',
      success_url: `${BASE_URL()}/payment/callback?ref=${order.reference}`,
      cancel_url: `${BASE_URL()}/status.html?ref=${order.reference}&cancelled=1`,
      client_reference_id: order.reference,
      customer_email: customer.email,
      'line_items[0][quantity]': '1',
      'line_items[0][price_data][currency]': order.currency.toLowerCase(),
      'line_items[0][price_data][unit_amount]': String(Math.round(order.amount * 100)),
      'line_items[0][price_data][product_data][name]': `Aura Tech Solutions order ${order.reference}`,
      'metadata[reference]': order.reference
    });
    const res = await fetch('https://api.stripe.com/v1/checkout/sessions', {
      method: 'POST',
      headers: { Authorization: `Bearer ${process.env.STRIPE_SECRET_KEY}`, 'Content-Type': 'application/x-www-form-urlencoded' },
      body
    });
    const data = await json(res);
    if (!data.url) throw new Error((data.error && data.error.message) || 'Stripe error');
    return { redirectUrl: data.url, providerRef: data.id };
  },
  async verify(order) {
    if (!order.provider_ref) return { paid: false };
    const res = await fetch(`https://api.stripe.com/v1/checkout/sessions/${encodeURIComponent(order.provider_ref)}`, {
      headers: { Authorization: `Bearer ${process.env.STRIPE_SECRET_KEY}` }
    });
    const d = await json(res);
    return { paid: d.payment_status === 'paid', amount: d.amount_total != null ? d.amount_total / 100 : undefined, currency: d.currency && d.currency.toUpperCase() };
  },
  // Verifies the Stripe-Signature header against the raw request body.
  verifyWebhook(rawBody, header) {
    const secret = process.env.STRIPE_WEBHOOK_SECRET;
    if (!secret || !header) return false;
    const parts = Object.fromEntries(header.split(',').map(p => p.split('=')));
    if (!parts.t || !parts.v1) return false;
    if (Math.abs(Date.now() / 1000 - Number(parts.t)) > 300) return false;
    const expected = crypto.createHmac('sha256', secret).update(`${parts.t}.${rawBody}`).digest('hex');
    const a = Buffer.from(expected), b = Buffer.from(parts.v1);
    return a.length === b.length && crypto.timingSafeEqual(a, b);
  }
};

const providers = { flutterwave, pesapal, stripe };

module.exports = { providers };
