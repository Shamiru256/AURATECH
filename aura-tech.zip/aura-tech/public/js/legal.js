(async () => {
  try {
    const { company } = await (await fetch('/api/config')).json();
    document.querySelectorAll('[data-company-email]').forEach(el => {
      if (!company.email) return;
      el.textContent = company.email;
      if (el.tagName === 'A') el.href = 'mailto:' + company.email;
    });
    document.querySelectorAll('[data-company-phone]').forEach(el => { if (company.phone) el.textContent = company.phone; });
  } catch { /* leave defaults */ }
  document.querySelectorAll('[data-year]').forEach(el => { el.textContent = new Date().getFullYear(); });
})();
