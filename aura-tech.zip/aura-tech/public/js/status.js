(async () => {
  const q = new URLSearchParams(location.search);
  const ref = q.get('ref');
  const box = document.getElementById('box');
  const render = (icon, title, text) => {
    box.innerHTML = '';
    const mk = (tag, cls, txt) => { const el = document.createElement(tag); if (cls) el.className = cls; el.textContent = txt; return el; };
    box.append(mk('div', 'big', icon), mk('h1', '', title), mk('p', '', text));
    const a = document.createElement('a'); a.className = 'btn'; a.href = '/'; a.textContent = 'Back to website';
    box.append(a);
  };

  if (!ref) return render('❓', 'No order found', 'This page needs an order reference.');
  if (q.get('cancelled')) return render('↩️', 'Payment cancelled', `Order ${ref} was not paid. You can go back and try again.`);

  async function check(tries) {
    try {
      const res = await fetch(`/api/orders/${encodeURIComponent(ref)}/status`);
      if (res.status === 404) return render('❓', 'Order not found', `We could not find order ${ref}.`);
      const o = await res.json();
      if (o.status === 'paid') return render('✅', 'Payment received', `Thank you! Order ${o.reference} is paid. Keep this reference for your records. We will contact you shortly.`);
      if (o.status === 'failed') return render('❌', 'Payment failed', `Order ${o.reference} was not completed. Please try again or contact us.`);
      if (tries > 0) { render('⏳', 'Confirming payment…', `Order ${o.reference} is still being confirmed. This page will update automatically.`); return setTimeout(() => check(tries - 1), 4000); }
      render('⏳', 'Still pending', `We have not yet received confirmation for order ${o.reference}. If you paid, it will update soon. Contact us with this reference if it does not.`);
    } catch {
      render('⚠️', 'Connection problem', 'Please refresh this page in a moment.');
    }
  }
  check(15);
})();
